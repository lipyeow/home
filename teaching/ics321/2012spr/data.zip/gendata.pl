#!/usr/bin/perl

use strict;

my $ntuples=100;

my @makers= qw(
Samsung
HP
Gateway
Lenovo
Dell
Asus
Apple
);

my @type=qw(
PC
Printer
Laptop
);

sub genIntData
{
   my ($min,$max)=@_;
   
   return ($min + int(rand ($max-$min)));
}


sub genFloatData
{
   my ($min,$max)=@_;
   
   return ($min + rand ($max-$min));
}


sub genDiscreteData
{
   my ($items)=@_;

   return $items->[ int(rand(scalar(@$items))) ];
}

my @productcsv=();

open(CSV,">pc.csv");
for(my $i=0; $i<$ntuples; $i++)
{
   my @tuple=();
   $tuple[0] = genIntData(1000,1999);
   $tuple[1] = genFloatData(1,4);
   $tuple[2] = genIntData(1,32);
   $tuple[3] = genIntData(250,2000);
   $tuple[4] = genIntData(300,3000);

   print CSV join(",", @tuple), "\n";

   my $maker= genDiscreteData(\@makers);
   push @productcsv, "$maker,$tuple[0],PC";
}
close CSV;

open(CSV,">laptop.csv");
for(my $i=0; $i<$ntuples; $i++)
{
   my @tuple=();
   $tuple[0] = genIntData(2000,2999);
   $tuple[1] = genFloatData(1,4);
   $tuple[2] = genIntData(1,32);
   $tuple[3] = genIntData(250,2000);
   $tuple[4] = genFloatData(10,18);
   $tuple[5] = genIntData(300,3000);

   print CSV join(",", @tuple), "\n";
   my $maker= genDiscreteData(\@makers);
   push @productcsv, "$maker,$tuple[0],PC";
}
close CSV;

open(CSV,">printer.csv");
for(my $i=0; $i<$ntuples; $i++)
{
   my @tuple=();
   $tuple[0] = genIntData(2000,2999);
   $tuple[1] = genDiscreteData(["true","false"]);
   $tuple[2] =
genDiscreteData(["int-jet","laser","dot-matrix"]);
   $tuple[3] = genIntData(50,1000);

   print CSV join(",", @tuple), "\n";
   my $maker= genDiscreteData(\@makers);
   push @productcsv, "$maker,$tuple[0],PC";
}
close CSV;

open(PROD,">product.csv");
print PROD join("\n", @productcsv);
close PROD;
