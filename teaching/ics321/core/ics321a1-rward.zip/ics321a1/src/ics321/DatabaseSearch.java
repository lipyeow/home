package ics321;

import java.io.IOException;
import java.util.ArrayList;

/**
 * class documentation here
 */
public interface DatabaseSearch {
	
	 /**
     * List of the different valid data type. 
     *
     */
	public static enum ColumnType {
		INT, CHAR, STRING, SHORT, NONE;
	}
	
	 /**
     * List of the different valid search types. 
     * EQUAL indicates the the search matches for identical values. 
     * GREATER indicates the the search matches for values strictly larger than the search item . 
     * LESS indicates the the search matches for values strictly smaller than the search item . 
     */
	public static enum SearchType {
		EQUAL, GREATER, LESS;
	}
	 
    /**
     * Sets the fully qualified file name of the file  to be searched by the reader. The data may
     * not all fit in memory. The method only checks for a valid file name and location not that it is formatted correctly.
     *
     * @param fileName The name of the file to be loaded.
     * @return if the file name is valid returns true 
     */
    public boolean naiveLoad(String fileName); 
   
     
    /**
     * Sets the fully qualified file name of the file  to be searched by the reader and converts the text to a binary file. 
     * The binary file writer is not buffered. The data may not all fit in memory. 
     * The file must be formatted correctly for the method to work.
     *
     * @param fileName The name of the file to be loaded.
     * @return if the file name is valid returns true 
     */
    public boolean binaryLoad(String fileName);
   
    
    /**
     * Sets the fully qualified file name of the file  to be searched by the reader and converts the text to a binary file. 
     * The binary file writer is  buffered. The data may not all fit in memory. 
     * The file must be formatted correctly for the method to work.
     *
     * @param fileName The name of the file to be loaded.
     * @return if the file name is valid returns true 
     */
    public boolean binaryBufLoad(String fileName);
    
    /**
     * Returns the pathname of the currently loaded database.
     *
     * @return fileName The name of the file to be loaded.
     */
    
    public String databaseName();
    
    
    /**
     * returns true if the current database file is saved to a binary version.
     * 
     * @return true if the current database file is saved to a binary version
     */
    
    public boolean binary();
    
    /**
     * Takes a columnNumber and a value and returns tuples that match the given value on the
     * given column for the specified type of search. This uses an unbuffered reader.
     * 
     * @param columnNumber The column of a row to be checked.
     * @param value The value which column values are checked against.
     * @param searchType the type of matching to use in the search Equal, Greater or Less
     * @return An ArrayList of the tuples that the data for the column specified match the search value
     * @throws IOException If the file cannot be read properly throws and exception.	
     */
    public ArrayList<String> naiveSearch(int columnNumber, String value,SearchType searchType) throws IOException; 
   
   
    
    /**
     * Takes a columnNumber and a value and returns tuples that match the given value on the
     * given column for the specified type of search. This uses a buffered reader.
     * 
     * @param columnNumber The column of a row to be checked.
     * @param value The value which column values are checked against.
     * @param searchType the type of matching to use in the search Equal, Greater or Less
     * @return An ArrayList of the tuples that the data for the column specified match the search value
     * @throws IOException If the file cannot be read properly throws and exception.	
     */
    public  ArrayList<String> naiveBufSearch(int columnNumber, String value, SearchType searchType)throws IOException; 
   
    
    /**
     * Takes a columnNumber and a value and returns tuples that match the given value on the
     * given column for the specified type of search. This uses a buffered reader and reads from a file converted to binary.
     * 
     * @param columnNumber The column of a row to be checked.
     * @param value The value which column values are checked against.
     * @param searchType the type of matching to use in the search Equal, Greater or Less
     * @return An ArrayList of the tuples that the data for the column specified match the search value
     * @throws IOException If the file cannot be read properly throws and exception.	
     */
    public  ArrayList<String> binarySearch(int columnNumber, String value, SearchType searchType) throws IOException;
   
    /**
     * Takes a columnNumber and a value and returns the binary representation for the given string based on the column.
     * 
     * @param columnNumber The column of a row to be checked.
     * @param value The value to be converted.
     * @return the integer that represents the value. 
     */
        
    public int convertTexttoBinary(int columnNumber, String value);
    /**
     * Runs the search specified by the command on the column indicated for the value specified.
     * If the search command isn't valid returns an empty list.
     * 
     * @param command The type of search.
     * @param searchFor The value to searched for.
     * @param columnNumber The column number that we want to search in for the searchFor value.
     * @return the list of the tuples that match for the specified search. 
     * @throws IOException If the file cannot be read properly throws and exception.	
     */
     public default ArrayList<String> runSearch(String command, String searchFor, int columnNumber) throws IOException {
		
		
		switch (command) {

		case "naiveSearchEq":
			return naiveSearch(columnNumber, searchFor, SearchType.EQUAL);
		case "naiveSearchGtr":
			return naiveSearch(columnNumber, searchFor, SearchType.GREATER);
		case "naiveSearchLess":
			return naiveSearch(columnNumber, searchFor, SearchType.LESS);
		case "naiveBufSearchEq":
			return naiveBufSearch(columnNumber, searchFor,SearchType.EQUAL);
		case "naiveBufSearchGtr":
			return naiveBufSearch(columnNumber, searchFor,SearchType.GREATER);
		case "naiveBufSearchLess":
			return naiveBufSearch(columnNumber, searchFor,SearchType.LESS);
		case "binarySearchEq":
			 return binarySearch(columnNumber,searchFor,SearchType.EQUAL);
		case "binarySearchGtr":
			 return binarySearch(columnNumber,searchFor,SearchType.GREATER);
		case "binarySearchLess":
			 return binarySearch(columnNumber,searchFor,SearchType.LESS);
		default:
			System.out.printf("Invalid command: %s %s %s ",command, columnNumber, searchFor);
			break;
		}
		return new ArrayList<String>();
	}
     /**
      * Takes a columnNumber and a value and returns the binary representation for the given string based on the column.
      * 
      */
         
    public static final String[] CommandList = { "naiveSearchEq","naiveSearchGtr","naiveSearchLess",
    											 "naiveBufSearchEq","naiveBufSearchGtr","naiveBufSearchLess",
    											 "binarySearchEq", "binarySearchGtr","binarySearchLess" };

}
