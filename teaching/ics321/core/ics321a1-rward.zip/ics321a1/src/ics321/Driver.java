package ics321;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {

	

	public static final String USAGE = "The driver program must have at least one.\n"
	+"The full location and file name that contains the list of commands to run." 
			+ "Optionally it may include the argument OutputRow to indicate that found tuples should be printed.";
	/**
	 * Program will run queries using the DatabaseReader Class.
	 * There must be at least one parameter the provide the location and name of the command file.
	 * Optionally it may include the argument OutputRow to indicate that found tuples should be printed.
	 * @param args  command line arguments
	 */
	public static void main(String[] args) {

		BufferedReader reader = null;
		String commadListFileName = null;
		boolean outputRow = false;
		try {
			DatabaseReader dr = new DatabaseReader();
			Timing stopwatch = new Timing();
			if (args.length == 0) {

				System.out.println("Command File not specified.");
				System.out.print(USAGE);
				return;
			}
			if (args.length > 2) {

				System.out.print("Error: Too Many Arguments");
				System.out.print(USAGE);
				return;
			}
			if (args.length == 2 && args[1].equals("OutputRow") )
			{
				outputRow = true;
			}
			
			commadListFileName = args[0];
			//open search commands file
			reader = new BufferedReader(new FileReader(commadListFileName));
			String line = null;

			stopwatch.start();
			//try to load database
			if (!loaddatabase(reader, commadListFileName, dr))
			{
				System.out.println("Load Failure cannot continue");
				//exit main- 
				// without correctly loaded database we cannot continue
				return;
			}
			stopwatch.stop();
			System.out.printf("Total load time %d msecs %n" , stopwatch.elapsed());

			
			//default number of repeats
			int repeat = 1;
			while ((line = reader.readLine()) != null) {
				// split current line in command file into type of search,
				// column to search and what to search for
				String[] arr = line.split(" ");
				int columnNumber = 0;
				if (arr.length != 3 && arr.length != 4 ) {
					System.out.println("Skipped line: " + line);
					System.out.println("Invalid Number of Arguments");
					//goto next search command
					continue;
				}
				try {

					columnNumber = Integer.parseInt(arr[1]);

				} catch (NumberFormatException e) {
					System.out.println("Skipped line: " + line);
					System.out.println("Error: Invalid Column Number");
					//goto next search command
					continue;
					
				}
				
				if(arr.length == 4 )
				{
					try {

						repeat = Integer.parseInt(arr[3]);

					} catch (NumberFormatException e) {
						System.out.println("Skipped line: " + line);
						System.out.println("Error: Invalid Column Number");
						//goto next search command
						continue;
						
					}
					
				}
				stopwatch.start();
				System.out.printf("Query %s searching for %s  in Column number %d %n",arr[0], arr[2],columnNumber);
				boolean first = true;
				for(int count = 0 ; count < repeat; count++  )
				{
					ArrayList<String> rows = dr.runSearch(arr[0], arr[2],columnNumber);
					if(first)
					{
						first = false;
						System.out.printf("%d rows found %n",rows.size());
						if(outputRow)
						{
							for( String row : rows)
							{
								System.out.println(row);
							}
						}
					}
				}
				stopwatch.stop();
				System.out.printf("Total query time %d msecs for %d queries %n",stopwatch.elapsed(),repeat );
			}

			
		} catch (FileNotFoundException e) {
			System.out.println("Command file " + args[0] + " not found");
			System.out.println(USAGE);
		} catch (IOException e) {
			System.out.println("IOException");
			System.out.println(USAGE);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}
	}

	
 /**
 * Loads the file specified in the commandfile will run queries using the DatabaseReader Class.
 * 
 * @param reader  the reader that has been opened on the commadListFileName.
 * @param commadListFileName  name of the file that contains the database commands.
 * @param dr  the Database reader to run the load command on.  
 * @returns true if the database is loaded false if it fails to load
 */ 
	private static boolean loaddatabase(BufferedReader reader,
		String commadListFileName, DatabaseSearch dr) throws IOException {
		
		String line;
		if ((line = reader.readLine()) != null) {
			String[] arr = line.split(" ");
			if (arr[0].equalsIgnoreCase("naiveLoad") && arr.length == 2) {
				return dr.naiveLoad(arr[1]);
			}
			else if (arr[0].equalsIgnoreCase("binaryLoad") && arr.length == 2){
				return dr.binaryLoad(arr[1]);
			}
			else if (arr[0].equalsIgnoreCase("binaryBufLoad")	&& arr.length == 2){
					return dr.binaryBufLoad(arr[1]);
			} else {

				System.out.println("Error:  Command File "
						+ commadListFileName
						+ "does not have a load command as the first line");
				return false;
			}
		} else {
			System.out.println("Error: Command File " + commadListFileName
					+ " is  empty");
			return false;

		}
	}
}
