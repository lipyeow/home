package ics321;
/**
 * A simple timing class to estimate performance.
 * 
 */
public class Timing {
    private long startTime;
    private long stopTime;
   
    /**
     * Sets the start and stop time to zero. 
     */
    public Timing() {
    	 stopTime = 0;
         startTime = 0;
    }
  
    /**
    * Sets the start to the current time and the stop time to zero. 
    */
    public void start() {
        startTime = System.currentTimeMillis();
        stopTime = 0;  
    }

    /**
    * Sets the stop time to the current time. 
    */
    public void stop() {
        stopTime = System.currentTimeMillis();
    }
   
    /**
     * Gets the number of milliseconds the timer ran for.
     *  If the timer is still running returns the amount of time elapsed 
     *  from the start time to the current time.
     *  @return the number of milliseconds the timer ran for.
     */
    public long elapsed()
    {
    	if(stopTime == 0)
    	{
    		return(System.currentTimeMillis() - startTime);
    	}
    	else
    	{
    		return(stopTime - startTime);
    	}
    	
    }
   
}
