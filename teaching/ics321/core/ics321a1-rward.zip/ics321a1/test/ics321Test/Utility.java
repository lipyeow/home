package ics321Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import ics321.DatabaseReader;
import ics321.DatabaseSearch.SearchType;

import java.io.IOException;
import java.util.ArrayList;

public class Utility {

	public static int testQuery(String searchCommand,int searchColumn, String searchFor, int expectedRows, SearchType st) 
	{
		
		DatabaseReader dr = new DatabaseReader();
		assertTrue(dr.binaryBufLoad("DatabaseFiles/largeOrders.tbl"));
		
		
		ArrayList<String> results = null;
		try {
			results = dr.runSearch(searchCommand, searchFor, searchColumn);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		 
		assertEquals(expectedRows, results.size());
		
		int searchedOn = dr.convertTexttoBinary(searchColumn, searchFor);
		  
		for(String row : results) 
		{
			  String[] columns = row.split("[|]",10);
			  int found = dr.convertTexttoBinary(searchColumn, columns[searchColumn-1]);
			  if(searchColumn ==9)
			  {
				  found = columns[searchColumn-1].compareTo(searchFor);
				  searchedOn = 0;
			  }
			  
			  switch(st)
			  {
			  	case EQUAL:
			  		assertEquals(searchFor,columns[searchColumn-1]);
			  		break;
			  	case GREATER:
			  		 assertTrue( found >  searchedOn);
			  		 break;
			  	case LESS:
			  		 assertTrue( found <  searchedOn);
			  		 break;
			  	default:
			  		fail("Invalid Search Type");
			  		break;
				   
			  }
			  
		}
		return 	results.size();
		
	}
}
