package ics321Test;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import ics321.Driver;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestDriver {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInvalidFileName() {
				
	    String args[] = {"BadCommandFileName"};	    	    
	    String expected = "Command file BadCommandFileName not found"+Driver.USAGE;
	    expected = expected.replaceAll("(\\r|\\n)", "");
	    assertEquals(expected, testMain(args));
	  
		
	}
	
	@Test
	public void testInvalidSearchCommand() {
				
	    String args[] = {"TestCommandFiles/InvalidCommandFile.txt"};	    	    
	    String expected = "Invalid command: BadCommand 3 F";
	    String output = testMain(args);
	    assertTrue(output, output.contains(expected));
	    
	  
	  
		
	}
	
	@Test
	public void testValidNaiveSearchCommand() {
				
	    String args[] = {"TestCommandFiles/ValidCommandFile.txt"};	    	    
	    String notExpected = "Invalid command:";
	    String output = testMain(args);
	    //make sure this isn't failing on load too
	    assertFalse(output, output.contains("Load Failure cannot continue"));
	    assertFalse(output, output.contains(notExpected));
	    
	  
	  
		
	}
	
	@Test
	public void missingLoadCommand() {
				
	    String args[] = {"TestCommandFiles/MissingLoadCommand.txt"};	    	    
	    String expected = "Error:  Command File " +  args[0]  + "does not have a load command as the first line";
	    String output = testMain(args);
	    assertTrue(output, output.contains(expected));
	  
		
	}
	@Test
	public void emptyCommandFile() {
				
	    String args[] = {"TestCommandFiles/EmptyCommandFile.txt"};	  	    
	    String expected = "Error: Command File " +  args[0]  + " is  empty";
	    String output = testMain(args);
	    assertTrue(output, output.contains(expected));
	  
		
	}
	
	@Test
	public void testTooManyArguments() {
				
	    String args[] = {"FileName", "OutputRow", "ExtraArgument" };
	    
	    String expected = "Error: Too Many Arguments"+Driver.USAGE;
	    expected = expected.replaceAll("(\\r|\\n)", "");
	    assertEquals(expected, testMain(args));
	   
	    
	   
	}
	
	@Test
	public void testTooFewArguments() {
				
	    String args[] = {};	
	    String expected = "Command File not specified."+Driver.USAGE;
	    expected = expected.replaceAll("(\\r|\\n)", "");
	    assertEquals(expected, testMain(args));
	}
	
	
	private String testMain( String args[] )
	{
			
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    PrintStream ps = new PrintStream(baos);
	    // IMPORTANT: Save the old System.out!
	    PrintStream old = System.out;
	    // Tell Java to use your temporary stream
	    System.setOut(ps);
	    Driver.main(args);
	    // Put things back
	    System.out.flush();
	    System.setOut(old);
	    // return main output
	    return baos.toString().replaceAll("(\\r|\\n)", "");
	    
	}
}
	
	


