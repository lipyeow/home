package ics321Test;

import static org.junit.Assert.*;
import ics321.DatabaseReader;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestConvertToBinary {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void ConvertColumn1() {
		
		DatabaseReader dr = new DatabaseReader();
	    int found = dr.convertTexttoBinary(1, "1");
	    assertEquals(1, found);
	    
	    found = dr.convertTexttoBinary(1, "3455");
	    assertEquals(3455, found);
	    
	    found = dr.convertTexttoBinary(1, "9999");
	    assertEquals(9999, found);
	}
	
	@Test
	public void ConvertColumn2() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn3() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn4() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn5() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn6() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn7() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn8() {
		
		fail("Not Implmented");
	}
	
	@Test
	public void ConvertColumn9() {
		
		fail("Not Implmented");
	}

}
