package ics321Test;
import ics321.DatabaseSearch.SearchType;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
/**
 * 
 */

/**
 * @author Robert
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestNaiveSearchLess {

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	
	@Before
	public void setUp() throws Exception {
	}

	
	@After
	public void tearDown() throws Exception {
	}

		
	@Test
	public void testSearchColumn1All() {
		
		
		Utility.testQuery("naiveSearchLess",1, "999999999", 1500,SearchType.LESS);
		
	}
	@Test
	public void testSearchColumn1None() {
		
		
		Utility.testQuery("naiveSearchLess",1, "0", 0,SearchType.LESS);
		
	}
	@Test
	public void testSearchColumn1Mid() {
		
		
		Utility.testQuery("naiveSearchLess",1, "5955", 1490,SearchType.LESS);
		Utility.testQuery("naiveSearchLess",1, "10", 7,SearchType.LESS);
		
	}
		
		@Test
		public void testSearchColumn2All() {
			
			
			Utility.testQuery("naiveSearchLess",2, "9999999", 1500,SearchType.LESS);
			
		}
		@Test
		public void testSearchColumn2None() {
			
			
			Utility.testQuery("naiveSearchLess",2, "0", 0,SearchType.LESS);
			
		}
			@Test
		public void testSearchColumn2Mid() {
			
			
				Utility.testQuery("naiveSearchLess",2, "100", 971,SearchType.LESS);
				Utility.testQuery("naiveSearchLess",2, "9", 78,SearchType.LESS);
			
		}
			
			@Test
			public void testSearchColumn3All() {
				
				
				Utility.testQuery("naiveSearchLess",3, "z", 1500,SearchType.LESS);
				
			}
			@Test
			public void testSearchColumn3None() {
				
				
				Utility.testQuery("naiveSearchLess",3, " ", 0,SearchType.LESS);
				
			}
				@Test
			public void testSearchColumn3Mid() {
				
				
					Utility.testQuery("naiveSearchLess",3, "O", 728,SearchType.LESS);
					
				
			}
				
				@Test
				public void testSearchColumn4All() {
					
					
					Utility.testQuery("naiveSearchLess",4, "99999999.99", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn4None() {
					
					
					Utility.testQuery("naiveSearchLess",4, "0.0", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn4Mid() {
					
					
						Utility.testQuery("naiveSearchLess",4, "156999.99", 1226,SearchType.LESS);
						
					
				}
				@Test
				public void testSearchColumn5All() {
					
					
					Utility.testQuery("naiveSearchLess",5, "2900-11-03", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn5None() {
					
					
					Utility.testQuery("naiveSearchLess",5, "1900-11-03", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn5Mid() {
					
					
						Utility.testQuery("naiveSearchLess",5, "1995-11-03", 874,SearchType.LESS);
						
					
				}
				
				@Test
				public void testSearchColumn6ALL() {
					
					
					Utility.testQuery("naiveSearchLess",6, "6-ABOVE", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn6None() {
					
					
					Utility.testQuery("naiveSearchLess",6, "0-NONE", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn6Mid() {
					
					
						Utility.testQuery("naiveSearchLess",6, "3-MEDIUM", 595,SearchType.LESS);
						
					
				}
				

				@Test
				public void testSearchColumn7All() {
					
					
					Utility.testQuery("naiveSearchLess",7, "Clerk#000099999", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn7None() {
					
					
					Utility.testQuery("naiveSearchLess",7, "Clerk#000000000", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn7Mid() {
					
					
						Utility.testQuery("naiveSearchLess",7, "Clerk#000000104", 137,SearchType.LESS);
						
					
				}
				

				@Test
				public void testSearchColumn8All() {
					
					
					Utility.testQuery("naiveSearchLess",8, "1", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn8None() {
					
					
					Utility.testQuery("naiveSearchLess",8, "-1", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn8Mid() {
					
					
						Utility.testQuery("naiveSearchLess",8, "0", 0,SearchType.LESS);
						
					
				}
				

				@Test
				public void testSearchColumn9All() {
					
					
					Utility.testQuery("naiveSearchLess",9, "zzzzzzzzzzzzzzz", 1500,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn9None() {
					
					
					Utility.testQuery("naiveSearchLess",9, "             ", 0,SearchType.LESS);
					
				}
				@Test
				public void testSearchColumn9Mid() {
					
					
						Utility.testQuery("naiveSearchLess",9, "jjjjj", 765,SearchType.LESS);
						
					
				}
	
	
}  
