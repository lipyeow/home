package ics321Test;

import static org.junit.Assert.*;
import ics321.DatabaseReader;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestDatabaseName {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void naiveLoadValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.naiveLoad("DatabaseFiles/largeOrders.tbl");
	    assertEquals("DatabaseFiles/largeOrders.tbl", dr.databaseName());
	    
	}

	@Test
	public void naiveLoadInValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.naiveLoad("Not found");
	    assertEquals("", dr.databaseName());
	}
	@Test
	public void naiveLoadDirectoryName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.naiveLoad("DatabaseFiles");
	    assertEquals("", dr.databaseName());
	    
	    
	}
	
	@Test
	public void binaryLoadValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryLoad("DatabaseFiles/largeOrders.tbl");
	    assertEquals("DatabaseFiles/largeOrders.tbl", dr.databaseName());
	    
	}

	@Test
	public void binaryLoadInValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryLoad("Not found");
	    assertEquals("", dr.databaseName());
	}
	@Test
	public void binaryLoadDirectoryName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryLoad("DatabaseFiles");
	    assertEquals("", dr.databaseName());
	    
	    
	}
	

	@Test
	public void binaryBufLoadValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryBufLoad("DatabaseFiles/largeOrders.tbl");
	    assertEquals("DatabaseFiles/largeOrders.tbl", dr.databaseName());
	    
	}

	@Test
	public void binaryBufLoadInValidFileName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryBufLoad("Not found");
	    assertEquals("", dr.databaseName());
	}
	@Test
	public void binaryBufLoadDirectoryName() {
		
		DatabaseReader dr = new DatabaseReader();
		dr.binaryBufLoad("DatabaseFiles");
	    assertEquals("", dr.databaseName());
	    
	    
	}
}
