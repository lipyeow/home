package ics321Test;

import ics321.DatabaseSearch.SearchType;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
/**
 * 
 */

/**
 * @author Robert
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestNaiveSearchEq {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
		
	@Test
	public void testSearchEqColumn1Found() {
		
		
		Utility.testQuery("naiveSearchEq",1, "100", 1,SearchType.EQUAL);
		
	}
	@Test
	public void testSearchEqColumn1NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",1, "100000", 0,SearchType.EQUAL);
						
	}
	
	@Test
	public void testSearchEqColumn1FirstFound() {
		

		Utility.testQuery("naiveSearchEq",1, "1", 1,SearchType.EQUAL);
						
		
		
	}
	
	@Test
	public void testSearchEqColumn1LastFound() {

		Utility.testQuery("naiveSearchEq",1, "5988", 1,SearchType.EQUAL);
		
	}
	@Test
	public void testSearchEqColumn1MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",1, "39", 4,SearchType.EQUAL);
		
	}
	
	@Test
	public void testSearchEqColumn2Found() {
		
		
		Utility.testQuery("naiveSearchEq",2, "777", 1,SearchType.EQUAL);
				
		
	}
	@Test
	public void testSearchEqColumn2NotFound() {
		
		Utility.testQuery("naiveSearchEq",2, "779", 0,SearchType.EQUAL);
				
		
	}
	
	@Test
	public void testSearchEqColumn2FirstFound() {
		
		Utility.testQuery("naiveSearchEq",2, "111", 1,SearchType.EQUAL);
						
		
		
	}
	
	@Test
	public void testSearchEqColumn2LastFound() {
		
		Utility.testQuery("naiveSearchEq",2, "999", 1,SearchType.EQUAL);
	
		
	}
	
	@Test
	public void testSearchEqColumn2MultiplyFound() {
		
	
		Utility.testQuery("naiveSearchEq",2, "88", 13,SearchType.EQUAL);
				
	}
	
	@Test
	public void testSearchEqColumn3Found() {
		

		Utility.testQuery("naiveSearchEq",3, "T", 1,SearchType.EQUAL);		
		
	}
	@Test
	public void testSearchEqColumn3NotFound() {
		
		Utility.testQuery("naiveSearchEq",3, "X", 0,SearchType.EQUAL);
		
		
	}
	
	@Test
	public void testSearchEqColumn3FirstFound() {
		Utility.testQuery("naiveSearchEq",3, "A", 1,SearchType.EQUAL);
			
		
	}
	
	@Test
	public void testSearchEqColumn3LastFound() {
		
		Utility.testQuery("naiveSearchEq",3, "Z", 1,SearchType.EQUAL);
						
		
		
	}
	
	@Test
	public void testSearchEqColumn3MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",3, "M", 4,SearchType.EQUAL);						
		
		
	}
	@Test
	public void testSearchEqColumn4Found() {
		
			
		Utility.testQuery("naiveSearchEq",4, "125170.86", 1,SearchType.EQUAL);	
				
		
	}
	@Test
	public void testSearchEqColumn4NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",4, "99.99", 0,SearchType.EQUAL);
						
		
		
	}
	
	@Test
	public void testSearchEqColumn4FirstFound() {
		
		Utility.testQuery("naiveSearchEq",4, "131251.81", 1,SearchType.EQUAL);
			
		
	}
	
	@Test
	public void testSearchEqColumn4LastFound() {
		
		Utility.testQuery("naiveSearchEq",4, "41655.51", 1,SearchType.EQUAL);
		
		
	}
	
	@Test
	public void testSearchEqColumn4MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",4, "22.22", 5,SearchType.EQUAL);
			
	}
	@Test
	public void testSearchEqColumn5Found() {
			
		Utility.testQuery("naiveSearchEq",5, "1997-09-05", 1,SearchType.EQUAL);
						
	}
	@Test
	public void testSearchEqColumn5NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",5, "2022-09-05", 0,SearchType.EQUAL);					
		
		
	}
	
	@Test
	public void testSearchEqColumn5FirstFound() {
		
		
		Utility.testQuery("naiveSearchEq",5, "1996-01-02", 1,SearchType.EQUAL);
				
		
	}
	
	@Test
	public void testSearchEqColumn5LastFound() {
	
		Utility.testQuery("naiveSearchEq",5, "1907-11-22", 1,SearchType.EQUAL);
		
	}
	
	@Test
	public void testSearchEqColumn5MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",5, "1993-11-22", 3,SearchType.EQUAL);
		
		
						
		
		
	}
	
	@Test
	public void testSearchEqColumn6NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",6, "7-WHAT", 0,SearchType.EQUAL);					
		
		
	}
	
		
	@Test
	public void testSearchEqColumn6Type1Found() {
		
		Utility.testQuery("naiveSearchEq",6, "1-URGENT", 306,SearchType.EQUAL);
		
				
		
	}
	@Test
	public void testSearchEqColumn6Type2Found() {
		
		Utility.testQuery("naiveSearchEq",6, "2-HIGH", 289,SearchType.EQUAL);
		
				
		
	}
	@Test
	public void testSearchEqColumn6Type3Found() {
		
		Utility.testQuery("naiveSearchEq",6, "3-MEDIUM", 305,SearchType.EQUAL);
		
				
		
	}
	@Test
	public void testSearchEqColumn6Type4Found() {
		
		Utility.testQuery("naiveSearchEq",6, "4-NOT SPECIFIED", 312,SearchType.EQUAL);
		
				
		
	}
	@Test
	public void testSearchEqColumn6Type5Found() {
		
		Utility.testQuery("naiveSearchEq",6, "5-LOW", 288,SearchType.EQUAL);
		
				
		
	}
	@Test
	public void testSearchEqColumn7Found() {
			
		Utility.testQuery("naiveSearchEq",7, "Clerk#000001692", 1,SearchType.EQUAL);
						
	}
	@Test
	public void testSearchEqColumn7NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",7, "Clerk#000091692", 0,SearchType.EQUAL);					
		
		
	}
	
	@Test
	public void testSearchEqColumn7FirstFound() {
		
		
		Utility.testQuery("naiveSearchEq",7, "Clerk#000001111", 1,SearchType.EQUAL);
				
		
	}
	
	@Test
	public void testSearchEqColumn7LastFound() {
	
		Utility.testQuery("naiveSearchEq",7, "Clerk#000009999", 1,SearchType.EQUAL);
		
	}
	
	@Test
	public void testSearchEqColumn7MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",7, "Clerk#000000304", 3,SearchType.EQUAL);
		
				
	}
	
	@Test
	public void testSearchEqColumn8Found() {
			
		Utility.testQuery("naiveSearchEq",8, "0", 1500,SearchType.EQUAL);
						
	}
	@Test
	public void testSearchEqColumn8NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",8, "1", 0,SearchType.EQUAL);					
		
		
	}
	
	
	@Test
	public void testSearchEqColumn9Found() {
			
		Utility.testQuery("naiveSearchEq",9, "kly regular pinto beans. carefully unusual waters cajole never", 1,SearchType.EQUAL);
						
	}
	@Test
	public void testSearchEqColumn9NotFound() {
		
		
		Utility.testQuery("naiveSearchEq",9, "Not Found", 0,SearchType.EQUAL);					
		
		
	}
	
	@Test
	public void testSearchEqColumn9FirstFound() {
		
		
		Utility.testQuery("naiveSearchEq",9, "First Comment", 1,SearchType.EQUAL);
				
		
	}
	
	@Test
	public void testSearchEqColumn9LastFound() {
	
		Utility.testQuery("naiveSearchEq",9, "Last Comment", 1,SearchType.EQUAL);
		
	}
	
	@Test
	public void testSearchEqColumn9MultiplyFound() {
		
		Utility.testQuery("naiveSearchEq",9, "Test multiple match", 3,SearchType.EQUAL);
		
		
						
		
		
	}
}  
