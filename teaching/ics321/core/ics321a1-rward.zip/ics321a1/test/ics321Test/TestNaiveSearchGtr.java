package ics321Test;
import ics321.DatabaseSearch.SearchType;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
/**
 * 
 */

/**
 * @author Robert
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestNaiveSearchGtr {

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	
	@After
	public void tearDown() throws Exception {
	}

		
	@Test
	public void testSearchColumn1All() {
		
		
		Utility.testQuery("naiveSearchGtr",1, "0", 1500,SearchType.GREATER);
		
	}
	@Test
	public void testSearchColumn1None() {
		
		
		Utility.testQuery("naiveSearchGtr",1, "9999999", 0,SearchType.GREATER);
		
	}
	@Test
	public void testSearchColumn1Mid() {
		
		
		Utility.testQuery("naiveSearchGtr",1, "5955", 9,SearchType.GREATER);
		Utility.testQuery("naiveSearchGtr",1, "10", 1493,SearchType.GREATER);
		
	}
		
		@Test
		public void testSearchColumn2All() {
			
			
			Utility.testQuery("naiveSearchGtr",2, "0", 1500,SearchType.GREATER);
			
		}
		@Test
		public void testSearchColumn2None() {
			
			
			Utility.testQuery("naiveSearchGtr",2, "9999999", 0,SearchType.GREATER);
			
		}
			@Test
		public void testSearchColumn2Mid() {
			
			
				Utility.testQuery("naiveSearchGtr",2, "100", 512,SearchType.GREATER);
				Utility.testQuery("naiveSearchGtr",2, "9", 1422,SearchType.GREATER);
			
		}
			
			@Test
			public void testSearchColumn3All() {
				
				
				Utility.testQuery("naiveSearchGtr",3, " ", 1500,SearchType.GREATER);
				
			}
			@Test
			public void testSearchColumn3None() {
				
				
				Utility.testQuery("naiveSearchGtr",3, "Z", 0,SearchType.GREATER);
				
			}
				@Test
			public void testSearchColumn3Mid() {
				
				
					Utility.testQuery("naiveSearchGtr",3, "O", 47,SearchType.GREATER);
					
				
			}
				
				@Test
				public void testSearchColumn4All() {
					
					
					Utility.testQuery("naiveSearchGtr",4, "0.0", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn4None() {
					
					
					Utility.testQuery("naiveSearchGtr",4, "99999999.99", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn4Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",4, "156999.99", 274,SearchType.GREATER);
						
					
				}
				@Test
				public void testSearchColumn5All() {
					
					
					Utility.testQuery("naiveSearchGtr",5, "1900-11-03", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn5None() {
					
					
					Utility.testQuery("naiveSearchGtr",5, "2995-11-03", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn5Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",5, "1995-11-03", 625,SearchType.GREATER);
						
					
				}
				
				@Test
				public void testSearchColumn6All() {
					
					
					Utility.testQuery("naiveSearchGtr",6, "0-NONE", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn6None() {
					
					
					Utility.testQuery("naiveSearchGtr",6, "5-LOW", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn6Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",6, "3-MEDIUM", 600,SearchType.GREATER);
						
					
				}
				

				@Test
				public void testSearchColumn7All() {
					
					
					Utility.testQuery("naiveSearchGtr",7, "Clerk#000000000", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn7None() {
					
					
					Utility.testQuery("naiveSearchGtr",7, "Clerk#000099999", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn7Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",7, "Clerk#000000104", 1361,SearchType.GREATER);
						
					
				}
				

				@Test
				public void testSearchColumn8All() {
					
					
					Utility.testQuery("naiveSearchGtr",8, "-1", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn8None() {
					
					
					Utility.testQuery("naiveSearchGtr",8, "1", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn8Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",8, "0", 0,SearchType.GREATER);
						
					
				}
				

				@Test
				public void testSearchColumn9All() {
					
					
					Utility.testQuery("naiveSearchGtr",9, "               ", 1500,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn9None() {
					
					
					Utility.testQuery("naiveSearchGtr",9, "zzzzzzzzzzzzzzzzzz", 0,SearchType.GREATER);
					
				}
				@Test
				public void testSearchColumn9Mid() {
					
					
						Utility.testQuery("naiveSearchGtr",9, "jjjjj", 735,SearchType.GREATER);
						
					
				}
	
	
}  
