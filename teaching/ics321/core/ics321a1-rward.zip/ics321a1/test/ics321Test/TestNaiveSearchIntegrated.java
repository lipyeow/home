package ics321Test;

import static org.junit.Assert.*;
import ics321.DatabaseSearch.SearchType;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestNaiveSearchIntegrated {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSearchColumn1() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",1, "0", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",1, "10", 0,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",1, "10", 7,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",1, "10", 1493,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}

	
	@Test
	public void testSearchColumn2() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",2, "0", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",2, "44", 19,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",2, "44", 421,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",2, "44", 1060,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	
	
	@Test
	public void testSearchColumn3() {
		
		
		int fullCount = Utility.testQuery("naiveSearchLess",3, "a", 1500,SearchType.LESS);
		int equallCount = Utility.testQuery("naiveSearchEq",3, "O", 725,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",3, "O", 728,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",3, "O", 47,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	
	@Test
	public void testSearchColumn4() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",4, "0.0", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",4, "37248.78", 1,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",4, "37248.78", 236,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",4, "37248.78", 1263,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	@Test
	public void testSearchColumn5() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",5, "1900-04-18", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",5, "1998-04-18", 2,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",5, "1998-04-18", 1432,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",5, "1998-04-18", 66,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	
	@Test
	public void testSearchColumn6() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",6, "0-None", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",6, "3-MEDIUM", 305,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",6, "3-MEDIUM", 595,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",6, "3-MEDIUM", 600,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	
	@Test
	public void testSearchColumn7() {
		
		
		int fullCount = Utility.testQuery("naiveSearchGtr",7, "Clerk#000000000", 1500,SearchType.GREATER);
		
		int equallCount = Utility.testQuery("naiveSearchEq",7, "Clerk#000000111", 1,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",7, "Clerk#000000111", 148,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",7, "Clerk#000000111", 1351,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	
	@Test
	public void testSearchColumn8() {
		
		
		int fullCount = Utility.testQuery("naiveSearchLess",8, "1", 1500,SearchType.LESS);
		
		int equallCount = Utility.testQuery("naiveSearchEq",8, "0", 1500,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",8, "0", 0,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",8, "0", 0,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
	@Test
	public void testSearchColumn9() {
		
		
		int fullCount = Utility.testQuery("naiveSearchLess",9, "zzzzzzzzzzzzzzzzzz", 1500,SearchType.LESS);
		
		int equallCount = Utility.testQuery("naiveSearchEq",9, "First Comment", 1,SearchType.EQUAL);
		int lessCount = Utility.testQuery("naiveSearchLess",9, "First Comment", 239,SearchType.LESS);
		int greaterCount = Utility.testQuery("naiveSearchGtr",9, "First Comment", 1260,SearchType.GREATER);
		
		assertEquals(fullCount, equallCount+ lessCount + greaterCount);
		
	}
}
