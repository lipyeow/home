
java -classpath $ORACLE_HOME/jdbc/lib/ojdbc6.jar:. runquery -q $1
