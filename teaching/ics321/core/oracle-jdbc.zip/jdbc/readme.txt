you need to change the password and username in mydb.properties file.

compile the java code with the right classpath (see compile.sh)

run the java program with the right classpath (see run.sh)
