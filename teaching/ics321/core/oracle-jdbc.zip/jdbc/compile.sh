
javac -classpath $ORACLE_HOME/jdbc/lib/ojdbc6.jar Timing.java runquery.java 
