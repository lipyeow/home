
db2 connect to bookdb
db2 prep myapp.sqc bindfile
db2 bind myapp.bnd
gcc myapp.c -I./include -L/home/db2inst1/sqllib/lib -ldb2

