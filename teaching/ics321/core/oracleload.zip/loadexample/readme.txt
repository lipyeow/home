
1. create the table using sqlplus first. Use "@crtable.sql" to execute the sql commands in crtable.sql file

2. exit sqlplus

3. run "sqlldr control=loadprod.ctl", enter your username and password.

4. run sqlplus again and do a select query to check that the data has been inserted.
