drop table product;

create table product(maker char(8), model int not null primary key, type char(8));
