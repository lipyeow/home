
basedir="/Users/lipyeow/sqllib"
javac -classpath $basedir/java/db2jcc.jar:$basedir/java/db2jcc_javax.jar:$basedir/java/db2jcc_license_cisuz.jar:$basedir/java/db2jcc_license_cu.jar Timing.java runquery.java 
