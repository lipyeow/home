To compile, execute the compile shell script:

./compile.sh

To run, execute the run shell script:

./run.sh commands.txt

You can add external libraries by adding their path into the 
classpath in the compile and run shell scripts
