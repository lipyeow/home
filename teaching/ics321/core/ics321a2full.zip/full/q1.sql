
-- find all personal consumption expenditure by function in
-- the first quarter of this year (2010) 
select f.func, f.pce
from pcefunc f
where f.year=2010 and f.quarter=1;

-- find the maximum personal consumption expenditure in
-- the first quarter of this year (2010) 
select f.func, f.pce
from pcefunc f
where f.year=2010 and f.quarter=1
and f.pce = 
(
select max(f.pce)
from pcefunc f
where f.year=2010 and f.quarter=1
)
;

-- which function, year and quarter saw the biggest increase
-- in personal consumption expenditure from year to year ?
select f1.func, f2.year,f1.year, f1.quarter, f2.pce, f1.pce 
from pcefunc f1, pcefunc f2
where f1.func = f2.func
and f1.quarter = f2.quarter
and f1.year+1 = f2.year
and ABS(f2.pce - f1.pce)=
(
select max(ABS(f2.pce - f1.pce))
from pcefunc f1, pcefunc f2
where f1.func = f2.func
and f1.quarter = f2.quarter
and f1.year+1 = f2.year
)
;

-- which function, year, quarter has the smallest personal
-- consumption expenditure of all time?
select f.func, f.year, f.quarter, f.pce
from pcefunc f
where f.pce = 
(
select min(f.pce)
from pcefunc f
)
;

-- find the total pce by function and year
--select f.func, f.year, sum(f.pce) as sumpce
--from pcefunc f
--group by f.func, f.year;

-- find the function, year and pce with the most yearly pce
select f.func, f.year, sum(f.pce) as sumpce
from pcefunc f
group by f.func, f.year
having sum(f.pce) =
(
select max(sumpce)
from
(
select f.func, f.year, sum(f.pce) as sumpce
from pcefunc f
group by f.func, f.year
)
)
;

-- find the year with the most yearly personal consumption
-- expenditure
select f.year, sum(f.pce) as sumpce
from pcefunc f
group by f.year
having sum(f.pce) = 
(
select max(sumpce)
from (
select f.year, sum(f.pce) as sumpce
from pcefunc f
group by f.year
)
)
;

-- find the total pce for each level2 product in the year
-- 2009
select t.level2, sum(p.pce)
from prodhierarchy t, pceprod p
where p.prod = t.level3 and year=2009
group by t.level2
;


select d.year, d.quarter, d.dpce, n.ndpce
from
(
select p.year, p.quarter, sum(p.pce) as dpce
from prodhierarchy t, pceprod p
where p.prod = t.level3 and t.level1='Goods'
group by p.year, p.quarter
) as d,
(
select p.year, p.quarter, sum(p.pce) as ndpce
from prodhierarchy t, pceprod p
where p.prod = t.level3 and t.level1='Services'
group by p.year, p.quarter
) as n
where d.year = n.year and d.quarter = n.quarter
        and d.dpce < n.ndpce
order by d.year, d.quarter desc
        ;

-- find the year(s), and difference between the
-- pce for goods and services as a percentage of the pce for
-- goods for the year(s) when the total pce for services is
-- larger than the total pce for goods. You want the results
-- sorted by most recent years first and the percentage
-- should be expressed with 2 decimal points.
select g.year,
Decimal( (float(s.pce)-float(g.pce))/float(g.pce)*100.0,
5,2)
from
(
select p.year, sum(p.pce) as pce
from prodhierarchy t, pceprod p
where p.prod = t.level3 and t.level1='Goods'
group by p.year
) as g,
(
select p.year, sum(p.pce) as pce
from prodhierarchy t, pceprod p
where p.prod = t.level3 and t.level1='Services'
group by p.year
) as s
where g.year = s.year 
        and g.pce < s.pce
order by g.year desc
        ;

--select max(f.pce)
--from pcefunc f
--where f.year = 2009
