drop table prodhierarchy;
create table prodhierarchy ( 
   level1 varchar(80),
   level2 varchar(80),
   level3 varchar(80) not null primary key);

drop table pceprod;
create table pceprod (
   prod varchar(80) not null,
   year int not null,
   quarter int not null,
   pce int,
   primary key(prod,year,quarter),
   foreign key(prod) references prodhierarchy
);

drop table pcefunc;
create table pcefunc (
   func varchar(80) not null,
   year int not null,
   quarter int not null,
   pce int,
   primary key(func,year,quarter)
);
