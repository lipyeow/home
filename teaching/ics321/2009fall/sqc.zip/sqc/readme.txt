
db2 connect to bookdb
db2 prep myapp.sqc bindfile
db2 bind myapp.bnd
gcc -m64 myapp.c -I/Users/lipyeow/sqllib/include -L/Users/lipyeow/sqllib/lib -ldb2

