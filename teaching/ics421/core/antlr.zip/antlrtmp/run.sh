
classpath="/Applications/ANTLRWorks.app/Contents/Resources/Java/antlrworks.jar:."

java -cp $classpath TestSQL

