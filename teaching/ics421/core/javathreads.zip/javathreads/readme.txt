to compile:

javac SimpleThreads.java

to run:

java SimpleThreads
